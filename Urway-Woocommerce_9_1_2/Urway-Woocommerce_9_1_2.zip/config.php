<?php
define('WC_CUSTOM_PLUGIN_GATEWAY_NAME', 'URWAY Payment');

?>