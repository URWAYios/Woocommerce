jQuery(document).ready(function($) {
    console.log("Urway Admin Script Loaded");
    // Custom logic for admin settings page
});
